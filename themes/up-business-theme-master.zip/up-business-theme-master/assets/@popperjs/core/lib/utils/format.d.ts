export default function format(str: string, ...args: Array<string>): string;
