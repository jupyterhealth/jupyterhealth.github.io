export default function getAltLen(len: "width" | "height"): "width" | "height";
